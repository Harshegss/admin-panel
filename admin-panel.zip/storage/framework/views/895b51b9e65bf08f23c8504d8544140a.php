<?php if(Auth::check()): ?>
<!DOCTYPE html>
<html lang="en">

<head> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- Primary Meta Tags -->
<title>Dashboard - <?php echo e(env('APP_NAME')); ?></title>

<meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#ffffff">
<link rel="shortcut icon" href="<?php echo e(asset('favicon-1.png')); ?>">

<!-- Sweet Alert -->
<link type="text/css" href="<?php echo e(asset('admin/vendor/sweetalert2/dist/sweetalert2.min.css')); ?>" rel="stylesheet">

<!-- Notyf -->
<link type="text/css" href="<?php echo e(asset('admin/vendor/notyf/notyf.min.css')); ?>" rel="stylesheet">

<!-- Volt CSS -->
<link type="text/css" href="<?php echo e(asset('admin/css/volt.css')); ?>" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
</head>

<body>
  
        <!-- NOTICE: You can use the _analytics.html partial to include production code specific code & trackers -->
        
        <nav class="navbar navbar-dark navbar-theme-primary px-4 col-12 d-lg-none">
    <a class="navbar-brand me-lg-5" href="<?php echo e(url('/')); ?>">
      <?php echo e(env('APP_NAME')); ?>

    </a>
    <div class="d-flex align-items-center">
        <button class="navbar-toggler d-lg-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

        <nav id="sidebarMenu" class="sidebar d-lg-block bg-gray-800 text-white collapse" data-simplebar>
  <div class="sidebar-inner px-4 pt-3">
    <div id="mainForm">

      
  </div>
    <ul class="nav flex-column pt-3 pt-md-0">
      
      
      <li role="separator" ></li>

      
      <li class="nav-item" role="separator">
        
        <button type="button" id="updateMyElement" class="btn btn-secondary d-flex align-items-center justify-content-center btn-upgrade-pro fw-bold" >Update</button>
      </li>
    </ul>


  </div>
</nav>
<?php if(Session::has('message')): ?>
<div class="toast show position-fixed" role="alert" aria-live="assertive" aria-atomic="true" style="z-index: 9999999; bottom:20px; right:20px; box-shadow: 0 1px 13px 3px rgb(0 0 0 / 10%), 0 1px 2px 0 rgb(0 0 0 / 6%);">
  <div class="toast-header">
    <img src="<?php echo e(asset('assets/img/favicon.png')); ?>" class="rounded me-2" alt="...">
    <strong class="me-auto"><?php echo e(env('APP_NAME')); ?></strong>
    <small></small>
    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
  </div>
  <div class="toast-body">
    <?php echo e(Session::get('message')); ?>

  </div>
</div>
<?php endif; ?>
        <main class="content vh-100 py-4">
<?php echo $__env->yieldContent('content'); ?>
        



        </main>

    <!-- Core -->
<script src="<?php echo e(asset('admin/vendor/@popperjs/core/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- Volt JS -->
<script src="<?php echo e(asset('admin/js/volt.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/4.20.0/standard/ckeditor.js"></script>

<script>
  $('.contents_textarea').each(function () {
      CKEDITOR.replace($(this).prop('id'));
  });

</script>

</body>

</html>
<?php else: ?>
<script>window.location="<?php echo e(url('dashboard/sign-in')); ?>"</script>
<?php endif; ?><?php /**PATH D:\wamp64\www\admin-panel\resources\views/admin/main.blade.php ENDPATH**/ ?>